module FOM
    using GeographicLib

    struct Radial
        line::GeodesicLine
        waypt::Vector{NamedTuple{(:lon, :lat, :baz, :dist, :angle), NTuple{5, Float64}}}
        st_lat::Float64
        st_lon::Float64
        bearing::Float64
        dist::Float64

        function Radial(lat::Float64, lon::Float64, b::Float64, d::Float64, n::Int64)
            line = GeodesicLine(lon, lat, azi=b, dist = d)
            waypt = waypoints(line; n=n)
            new(line, waypt, lat, lon, b, d)
        end
    end




#end of module
end
