module TL

    using UnderwaterAcoustics
    using GeoArrays
    using Plots


    struct TLoss
        bathymetry::Vector{Any}
        radial::Vector{Any}
        source::NarrowbandAcousticSource
        receiver::AcousticReceiverGrid2D
        environment::UnderwaterEnvironment
        prop_model::Bellhop
        source_x::Float64
        source_z::Float64
        source_freq::Float64
        rec_xstep::Float64
        rec_zstep::Float64
        rec_xdim::Float64
        rec_zdim::Float64
        bathy_range::Vector{Float64}
        SSP::Array{Float32, 4}
        tl_lat::Float64
        tl_lon::Float64
        ssp_depth::Vector{Float64}
        TL::Matrix{Float32}


    end


    function EnvTest(bathymetry::Vector{Any}, SSP::Array{Float32,4}, tl_lat::Vector{Float64}, tl_lon::Vector{Float64},ssp_depth::Vector{Float64},bathy_range::Vector{Float64})
        env = UnderwaterEnvironment(
            seasurface = Vacuum,
            seabed = SandyClay,
            samp_ssp = SampledSSP(ssp_depth,SSP[tl_lon,tl_lat,:,1]),
            samp_bathy = SampledDepth(bathy_range, bathymetry,:linear)
        )
        environment = new(env) #set using EnvTest parameters
    end

    function Bellhop_model(environment::UnderwaterEnvironment, bathymetry,::Vector{Any},source_x::Float64,
                            source_z::Float64,source_freq::Float64,rec_xstep::Float64,rec_zstep::Float64,rec_xdim::Float64,rec_zdim::Float64)
        prop_model = Bellhop(environment;gaussian=true)
        source = AcousticSource(source_x,source_z,source_freq)
        receiver = AcousticReceiverGrid2D(0.0,bathy_range[2]/10,rec_xdims,-maximum(bathymetry),rec_zstep,rec_zdim)
        TL = transmissionloss(prop_model, source, receiver)
    end

#end of module
end
