using UnderwaterAcoustics
using Plots
using NetCDF
using GeoArrays
using GeographicLib

import YAML
import .FOM.Radial

include ("Radial.jl")

inputs = InputsTest.InputsTest.Inputs("C:\\NRL\\Git\\gitlab\\julia-fom\\TransmissionLoss\\src\\inputs.yml")

depth2 = ncread( inputs["netcdf"], "depth")
ss2 = ncread(inputs["netcdf"],"sound_speed")
lat = ncread(inputs["netcdf"],"lat")
lon = ncread(inputs["netcdf"],"lon")

bathy = GeoArrays.read(inputs["bathyGeotiff"])

rad_val = values(inputs["radials"])

for i in length(inputs["radials"])
    radial = FOM.FOM.Radial(value[i]["latitude"], value[i]["longitude"], value[i]["bearing"], value[i]["distance"], value[i]["numberOfPoints"])
    push!(radials2, radial)
end
