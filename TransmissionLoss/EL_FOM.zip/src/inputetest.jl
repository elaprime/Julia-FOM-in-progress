module InputsTest

    import YAML

    struct Inputs
        data::Dict{Symbol,Any}

        function Inputs(file::String)
            data = YAML.load_file(file)
            #new(YAML.load_file(file))

        end

    end





end
