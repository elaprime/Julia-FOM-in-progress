import .FOM.FOM.Radial

function main()
    lat = 0.0
    lon = 0.0
    b = 0.0
    d = 100.0
    n = 10
    radial = Radial(lat, lon, b, d, n)
    println(radial.waypt)
end

main()
