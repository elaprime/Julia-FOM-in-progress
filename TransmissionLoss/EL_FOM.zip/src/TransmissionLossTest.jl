using UnderwaterAcoustics
using Plots
using NetCDF
using GeoArrays
using GeographicLib
import YAML
include("Radial.jl")

import .FOM.Radial

#export Bellhop
#=function foo()
    depth2 = ncread("C:\\Users\\Emily\\OneDrive\\Documents\\NRL - UNO\\HYCOM.talisman_saber.006.nc","depth")
    ss2 = ncread("C:\\Users\\Emily\\OneDrive\\Documents\\NRL - UNO\\HYCOM.talisman_saber.006.nc","sound_speed")
    lat = ncread("C:\\Users\\Emily\\OneDrive\\Documents\\NRL - UNO\\HYCOM.talisman_saber.006.nc","lat")
    lon = ncread("C:\\Users\\Emily\\OneDrive\\Documents\\NRL - UNO\\HYCOM.talisman_saber.006.nc","lon")
    #bathy = ArchGDAL.read("C:\\Users\\Emily\\OneDrive\\Documents\\NRL - UNO\\bathy.tiff")


    #when reading in this data, there are missing values which i believe is causing an error in the transmissionloss method
    bathy = GeoArrays.read("C:\\Users\\Emily\\OneDrive\\Documents\\NRL - UNO\\bathy.tiff")
    #x = GeoArrays.interpolate!(bathy, IDW(:1))

    #what lat and lon to select here
    line = GeodesicLine(lon[12], lat[12], azi=0, dist=73152)
    wpts = waypoints(line, dist=914.4)

    #ranges = 0:1:73152
    depths = Array{Float64,1}(undef, length(wpts))
    ranges = Array{Float64,1}(undef, length(wpts))
    runningRange = 0
    idx = []
    #ranges = []

    for pnt in wpts
        # how to specify point here, using pnt won't work
        idx = indices(bathy, [160.0,5.0])
        bathyVector = bathy[idx[1],idx[1]]
        bathy2 = bathyVector[1]
        if bathy2 === missing
            bathy2 = 0
        end
        bathy2 = abs(bathy2)
        push!(depths, bathy2)
        runningRange += 914.4
        push!(ranges, runningRange)

    end


    println(size(ranges), size(depths))

    env = UnderwaterEnvironment(
        seasurface = Vacuum,
        seabed = SandyClay,
        ssp = SampledSSP(depth2, ss2[1,1,:,1], :linear),
        #does model want + or - values
        bathymetry = SampledDepth(ranges, depths, :linear))

    pm = Bellhop(env, gaussian=true)
    tx = AcousticSource(0.0,-5.0,1000.0)
    rx = AcousticReceiverGrid2D(1.0,0.1,1000, -40.0,0.2,200)
    x = transmissionloss(pm,tx,rx)
    Plots.plot(env; receivers=rx,transmissionloss=x)

end=#

inputs = InputsTest.InputsTest.Inputs("C:\\NRL\\Git\\gitlab\\julia-fom\\TransmissionLoss\\src\\inputs.yml")


depth2 = ncread( inputs["netcdf"], "depth")
ss2 = ncread(inputs["netcdf"],"sound_speed")
lat = ncread(inputs["netcdf"],"lat")
lon = ncread(inputs["netcdf"],"lon")

bathy = GeoArrays.read(inputs["bathyGeotiff"])

line2 = GeodesicLine(lon[250],lat[576], azi=90, dist=92600)
wpts = waypoints(line2, dist=914.4)


radials2 = []
lat1 = -34.00
lon1 = 109.03
bearing1 = 0.0
dist1 = 92600.0
bearing_inc = 360.0/10.0
n = 5

value = values(inputs["radials"])

for i in length(inputs["radials"]) #length of radials object from inputs
    #bearing1 += bearing_inc
    radial = FOM.FOM.Radial(value[i]["latitude"], value[i]["longitude"], value[i]["bearing"], value[i]["distance"], value[i]["numberOfPoints"])
    push!(radials2, radial)
end


outputs = RadTest.RadTest.Outputs("C:\\NRL\\Git\\gitlab\\julia-fom\\TransmissionLoss\\src\\outputDirectory\\rad_test.yml",radials)


bathy_depths = []
ranges =[]
runningRange = 0
idx = []
bathyVector = []


#for j in 1:1:length(radials2)

for k = 1:1:length(radials2)
    #need to get indices for ssp (only for 1st waypoint), graph ssp, vector of 40 depths, 1D
    pnt = radials2[k].waypt[k]
    idx = indices(bathy, (lon[k],lat[k]))
    bathyVector = bathy[idx[1],idx[2]]
    bathy2 = bathyVector[1]
    if bathy2 === missing
        bathy2 = 0
    end
    bathy2 = abs(bathy2)
    push!(bathy_depths, bathy2)
    push!(ranges, runningRange)
    runningRange += 914.4
end

println(size(ranges), size(bathy_depths))

range_vec=round.(Int,ranges)

ssp_depths = range(0,maximum(bathy_depths),length=40)
env = UnderwaterEnvironment(
    seasurface = Vacuum,
    seabed = SandyClay,
    #ssp = SampledSSP(0.0:20.0:40.0, [1540.0, 1510.0, 1520.0], :smooth),
    #ssp = SampledSSP(depth3, ssp1latlon, :linear),
    #ssp = SampledSSP(1:1:40,ss2[1,1,:,1]),
    ssp = SampledSSP(ssp_depths,ss2[1,1,:,1]),
    #ssp = IsoSSP{Vector{Float64}}(ss2[1,1,:,1]),
    #ssp = IsoSSP{Float64}(ss2[600,500,20,1]),
    bathymetry = SampledDepth(ranges, bathy_depths, :linear))
    #bathymetry = SampledDepth(0.0:50.0:100.0, [40,35.0,38.0], :linear))

pm = Bellhop(env;gaussian=true)
tx = AcousticSource(0.0,-5.0,1000.0)
rx = AcousticReceiverGrid2D(0.0,range_vec[2]/10,500, -maximum(bathy_depths),29.5,200)
x = transmissionloss(pm,tx,rx)
Plots.plot(env; receivers=rx,transmissionloss=x,ylim=[-6000,0], xlim = [10,25000])
